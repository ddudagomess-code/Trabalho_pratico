import java.time.LocalDateTime;
        import java.time.format.DateTimeFormatter;

public class Veiculo {
    private String placa;
    private LocalDateTime horaEntrada;

    // Construtor
    public Veiculo(String placa, LocalDateTime horaEntrada) {
        this.placa = placa;
        this.horaEntrada = horaEntrada;
    }

    // Getters
    public String getPlaca() {
        return placa;
    }

    public LocalDateTime getHoraEntrada() {
        return horaEntrada;
    }
}
