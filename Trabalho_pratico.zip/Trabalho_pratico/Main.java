import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {

    // Define o formato de exibição das datas
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM HH:mm");

    public static void main(String[] args) {
        // Capacidade definida
        Estacionamento estacionamento = new Estacionamento(10);
        Scanner scanner = new Scanner(System.in);
        int opcao = 0;

        do {
            System.out.println("\n####### SISTEMA DE ESTACIONAMENTO #######");
            System.out.println("1. Registrar Entrada");
            System.out.println("2. Registrar Saída");
            System.out.println("3. Vagas Disponíveis");
            System.out.println("4. Listar Veículos");
            System.out.println("5. Pesquisar Veículo");
            System.out.println("6. Relatório de Faturamento");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = scanner.nextInt();
                scanner.nextLine();
            } catch (java.util.InputMismatchException e) {
                System.out.println("Entrada inválida. Digite um número.");
                scanner.nextLine();
                opcao = -1;
            }

            switch (opcao) {
                case 1:
                    System.out.print("Digite a Placa do veículo: ");
                    String placaEntrada = scanner.nextLine();

                    System.out.println("Escolha o horário de entrada:");
                    System.out.println("1. Hora Atual");
                    System.out.println("2. Digitar hora manual (Simulação)");
                    int opHora = scanner.nextInt();
                    scanner.nextLine();

                    LocalDateTime dataEntrada;
                    if (opHora == 2) {
                        System.out.print("Simulação: Digite a HORA de entrada (0-23): ");
                        int hora = scanner.nextInt();
                        System.out.print("Simulação: Digite o MINUTO de entrada (0-59): ");
                        int minuto = scanner.nextInt();
                        scanner.nextLine();

                        // Cria a data de hoje com a hora e minuto que o usuário digitou
                        dataEntrada = LocalDateTime.now().withHour(hora).withMinute(minuto).withSecond(0).withNano(0);
                    } else {
                        dataEntrada = LocalDateTime.now();
                    }

                    Veiculo novoVeiculo = new Veiculo(placaEntrada.toUpperCase(), dataEntrada);
                    estacionamento.registrarEntrada(novoVeiculo);
                    break;

                case 2:
                    System.out.print("Digite a Placa para saída: ");
                    String placaSaida = scanner.nextLine();
                    estacionamento.registrarSaida(placaSaida.toUpperCase());
                    break;

                case 3:
                    System.out.println("Vagas livres: " + estacionamento.getVagasDisponiveis() +
                            " / Ocupadas: " + estacionamento.getVeiculosEstacionados().size());
                    break;

                case 4:
                    if (estacionamento.getVeiculosEstacionados().isEmpty()) {
                        System.out.println("Não há veículos estacionados no momento.");
                    } else {
                        System.out.println("\n--- Veículos Estacionados ---");
                        for (Veiculo v : estacionamento.getVeiculosEstacionados()) {
                            System.out.println("Placa: " + v.getPlaca() + " | Entrada: " + v.getHoraEntrada().format(FORMATTER));
                        }
                    }
                    break;

                case 5:
                    System.out.print("Digite a placa para pesquisar: ");
                    String placaBusca = scanner.nextLine();
                    Veiculo v = estacionamento.buscarVeiculo(placaBusca.toUpperCase());
                    if (v != null) {
                        System.out.println("Veículo encontrado! Entrada: " + v.getHoraEntrada().format(FORMATTER));
                    } else {
                        System.out.println("Veículo NÃO está no estacionamento.");
                    }
                    break;

                case 6:
                    System.out.printf("Total arrecadado até o momento: R$ %.2f%n", estacionamento.getTotalArrecadado());
                    break;

                case 0:
                    System.out.println("Sistema encerrado.");
                    break;

                default:
                    if (opcao != -1) {
                        System.out.println("Opção inválida!");
                    }
            }

        } while (opcao != 0);

        scanner.close();
    }
}
