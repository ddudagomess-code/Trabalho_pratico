import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class Estacionamento {
    private List<Veiculo> veiculos;
    private int capacidadeTotal;
    private double totalArrecadado;

    // Constantes de Preço
    private static final double PRECO_PRIMEIRA_HORA = 12.00;
    private static final double PRECO_HORA_ADICIONAL = 8.00;

    public Estacionamento(int capacidadeTotal) {
        this.veiculos = new ArrayList<>();
        this.capacidadeTotal = capacidadeTotal;
        this.totalArrecadado = 0.0;
    }

    // Retorna vagas disponíveis
    public int getVagasDisponiveis() {
        return capacidadeTotal - veiculos.size();
    }

    public void registrarEntrada(Veiculo veiculo) {
        if (getVagasDisponiveis() > 0) {
            veiculos.add(veiculo);
            System.out.println("Veículo " + veiculo.getPlaca() + " estacionado. Vagas restantes: " + getVagasDisponiveis());
        } else {
            System.out.println("Erro: Estacionamento lotado!");
        }
    }

    // Método de busca (uso do 'for' tradicional)
    public Veiculo buscarVeiculo(String placa) {
        for (Veiculo v : veiculos) {
            // Comparação ignorando maiúsculas/minúsculas
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                return v;
            }
        }
        return null;
    }

    // Calcula tempo, valor e registra saída
    public void registrarSaida(String placa) {
        Veiculo veiculo = buscarVeiculo(placa);

        if (veiculo == null) {
            System.out.println("Erro: Veículo com a placa " + placa + " não encontrado.");
            return;
        }

        LocalDateTime horaSaida = LocalDateTime.now();

        // CÁLCULO DE TEMPO EM MINUTOS
        long minutosTotais = ChronoUnit.MINUTES.between(veiculo.getHoraEntrada(), horaSaida);

        // GARANTE O ARREDONDAMENTO PARA CIMA (Regra do trabalho)
        if (minutosTotais <= 0) {
            minutosTotais = 1; // Pelo menos 1 minuto para garantir 1 hora
        }

        // Arredonda para a próxima hora cheia usando Math.ceil
        long horasCobradas = (long) Math.ceil(minutosTotais / 60.0);

        // CÁLCULO DO VALOR (Lógica com if/else)
        double valorPagar;
        if (horasCobradas == 1) {
            valorPagar = PRECO_PRIMEIRA_HORA;
        } else {
            // 12.00 + (Horas - 1) * 8.00
            valorPagar = PRECO_PRIMEIRA_HORA + (horasCobradas - 1) * PRECO_HORA_ADICIONAL;
        }

        // Atualiza o faturamento e remove o veículo
        totalArrecadado += valorPagar;
        veiculos.remove(veiculo);

        System.out.println("\n=== Recibo de Saída ===");
        System.out.println("Placa: " + veiculo.getPlaca());
        System.out.println("Tempo total: " + minutosTotais + " minutos (" + horasCobradas + " horas cobradas)");
        System.out.printf("Valor a pagar: R$ %.2f%n", valorPagar);
        System.out.println("=======================");
    }

    // Retorna a lista completa para exibição
    public List<Veiculo> getVeiculosEstacionados() {
        return veiculos;
    }

    public double getTotalArrecadado() {
        return totalArrecadado;
    }
}
